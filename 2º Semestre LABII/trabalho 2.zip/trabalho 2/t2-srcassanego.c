// Trabalho 2 - Caça-palavras feito pelo aluno Samuel Rech Cassanego
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
//Faz a impressão da matriz na tela para o usuário;
void imprime(int linha, int coluna, char **matriz)
{
  printf("\n");
  for (int i = 0; i < linha; i++)
  {
    for (int j = 0; j < coluna; j++)
    {
      printf(" %c", matriz[i][j]);
      printf(" | ");
    }
    printf("\n");
  }
}
//Faz o sorteio dos caracteres aleatórios que entraram na matriz;
void sorteio(int linha, int coluna, char **matriz)
{
  char alfabeto[] = "abcdefghijklmnopqrstuvwxyz"; //abcdefghijklmnopqrstuvwxyz
  srand(time(NULL));
  for (int i = 0; i < linha; i++)
  {
    for (int j = 0; j < coluna; j++)
    {
      matriz[i][j] = alfabeto[rand() % 26];
    }
  }
}
/*Verifica se a palavra desejada se encontra na matriz, primeiro busca se a primeira letra da palavra está na matriz e depois busca pela segunda letra
e assim sucessivamente em todas direções possíveis. Se a palavra é encontrada é escrito na tela a posição dela e a sua direção, caso contrário
é dada uma mensagem de erro. */
void verificaMatriz(int linha, int coluna, char **matriz, char busca[20])
{
  bool achou = false;
  int tam = strlen(busca), eixoXi = 0, eixoYi = 0, eixoXf = 0, eixoYf = 0, cont = 0;
  for (int i = 0; i < linha; i++)
  {
    for (int j = 0; j < coluna; j++)
    {
      if (busca[0] == matriz[i][j] && achou == false) //acha a primeira letra da palavra procurada
      {
        eixoXi = i;
        eixoYi = j;
        if ((i - 1) >= 0)
        {
          if (busca[1] == matriz[i - 1][j]) //verifica o norte (Vertical reversa)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i - z) >= 0)
              {
                if (busca[z] != matriz[i - z][j])
                {
                  achou = false;
                }
                eixoXf = (i - z);
                eixoYf = j;
              }
              else
              {
                achou = false;
              }
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Vertical Reversa, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        } //fim da verificação da vertical reversa
        if ((i + 1) < linha)
        {
          if (busca[1] == matriz[i + 1][j]) //verifica o sul (Vertical direta)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i + z) < linha)
              {
                if (busca[z] != matriz[i + z][j])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = (i + z);
              eixoYf = j;
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Vertical Direta, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da vertical direta
        if ((j + 1) < coluna)
        {
          if (busca[1] == matriz[i][j + 1]) //verifica o leste (Horizontal direta)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((j + z) < coluna)
              {
                if (busca[z] != matriz[i][j + z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = i;
              eixoYf = (j + z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Horizontal Direta, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da horizontal direta
        if ((j - 1) >= 0)
        {
          if (busca[1] == matriz[i][j - 1]) //verifica o oeste (Horizontal reversa)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((j - z) >= 0)
              {
                if (busca[z] != matriz[i][j - z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = i;
              eixoYf = (j - z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Horizontal Reversa, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da horizontal reversa
        if ((i - 1) >= 0 && (j + 1) < coluna)
        {
          if (busca[1] == matriz[i - 1][j + 1]) //verifica o nordeste (Diagonal secundária reversa)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i - z) >= 0 && (j + z) < coluna)
              {
                if (busca[z] != matriz[i - z][j + z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = (i - z);
              eixoYf = (j + z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Diagonal Secundária Reversa, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da Diagonal secundária reversa
        if ((i - 1) >= 0 && (j - 1) >= 0)
        {
          if (busca[1] == matriz[i - 1][j - 1]) //verifica o noroeste (Diagonal principal reversa)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i - z) >= 0 && (j - z) >= 0)
              {
                if (busca[z] != matriz[i - z][j - z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = (i - z);
              eixoYf = (j - z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Diagonal Principal Reversa, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da Diagonal principal reversa
        if ((i + 1) < linha && (j + 1) < coluna)
        {
          if (busca[1] == matriz[i + 1][j + 1]) //verifica o sudeste (Diagonal principal direta)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i + z) < linha && (j + z) < coluna)
              {
                if (busca[z] != matriz[i + z][j + z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = (i + z);
              eixoYf = (j + z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Diagonal Principal Direta, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da Diagonal principal direta
        if ((i + 1) < linha && (j - 1) >= 0)
        {
          if (busca[1] == matriz[i + 1][j - 1]) //verifica o sudoeste (Diagonal secundária direta)
          {
            achou = true;
            for (int z = 0; z < tam; z++)
            {
              if ((i + 1) < linha && (j - 1 >= 0))
              {
                if (busca[z] != matriz[i + z][j - z])
                {
                  achou = false;
                }
              }
              else
              {
                achou = false;
              }
              eixoXf = (i + z);
              eixoYf = (j - z);
            }
            if (achou == true && cont < 1)
            {
              printf("A palavra %s foi encontrada na Diagonal Segundária Direta, iniciando na posição [%d,%d] e terminando na posição [%d,%d]\n", busca, eixoXi, eixoYi, eixoXf, eixoYf);
              cont++;
            }
          }
        }//fim da verificação da Diagonal secundária direta
        if (achou == true)
        {
          cont = 0;
        }
      }
    }
  }
  if (achou == false && (cont > 1 || cont == 0 ))
  {
    printf("\nA palavra buscada não se encontra no caça-palavras. Tente outra palavra.\n");
  }
}
//Esta função faz a alocação dinâmica de memória da matriz
char **cria_matriz(int linha, int coluna)
{
  char **matriz;

  matriz = (char **)malloc(linha * sizeof(char *));

  for (int i = 0; i < linha; i++)
  {
    matriz[i] = (char *)malloc(coluna * sizeof(char));
  }

  return matriz;
}
//Esta função libera o espaço alocado da memória em que a matriz estava depois de terminado o código
void libera_matriz(char **matriz, int linha)
{
  for (int i = 0; i < linha; i++)
  {
    free(matriz[i]);
  }
  free(matriz);
}
//Recebe informações e chama as funções do caça-palavras
int main()
{
  int m = 0, n = 0;
  bool fimDeJogo = false;
  char palavra[20];
  char **matriz;
  printf("Digite o número de linhas da matriz do seu caça-palavras: ");
  scanf("%d", &m);
  printf("Digite o número de colunas da matriz do seu caça-palavras: ");
  scanf("%d", &n);
  matriz = cria_matriz(m, n);
  sorteio(m, n, matriz);
  imprime(m, n, matriz);
  while (fimDeJogo == false)
  {
    printf("\ndigite a palavra que deseja buscar ou '0' para parar o caça-palavras: ");
    scanf("%s", palavra);
    if (palavra[0] == '0')
    {
      fimDeJogo = true;
      printf("\nFim de jogo\n");
      libera_matriz(matriz, m);
    }
    else
    {
      verificaMatriz(m, n, matriz, palavra);
    }
  }
}