#include "menu.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

Aluno *pegaDadosAl(Aluno *lista)
{
  int telefone, matriculaAluno;
  char nomeAluno[30];

  printf("Criando...\n");
  printf("Digite o nome do aluno: ");
  scanf("%s", nomeAluno);
  printf("Digite o número de matrícula do aluno: ");
  scanf("%d", &matriculaAluno);
  printf("Digite o número de telefone do aluno: ");
  scanf("%d", &telefone);
  printf("\n");

  lista = insereUltimoA(lista, matriculaAluno, telefone, nomeAluno);

  return lista;
}
int pegaDadosAlDel(Aluno *lista)
{
  int matriculaAluno;
  printf("Deletando...\n");
  printf("Digite o número de matricula do aluno que deseja deletar: ");
  scanf("%d", &matriculaAluno);

  return matriculaAluno;
}

Disciplina *pegaDadosDi(Disciplina *lista)
{
  int idDisciplina, creditos;
  char nome[70];

  printf("Criando...\n");
  printf("Digite o nome da disciplina: ");
  scanf("%s", nome);
  printf("Digite o código da disciplina: ");
  scanf("%d", &idDisciplina);
  printf("Digite o número créditos: ");
  scanf("%d", &creditos);
  printf("\n");

  lista = insereUltimoD(lista, idDisciplina, nome, creditos);

  return lista;
}
int pegaDadosDiDel(Disciplina *lista)
{
  int idDisc;
  printf("Deletando...\n");
  printf("Digite o código da disciplina: ");
  scanf("%d", &idDisc);
  return idDisc;
}

Turma *pegaDadosTu(Turma *lista, Disciplina *listaD)
{
  int idTurma, vagas;
  char dia[15], horario[6], sala[10], materia[70];

  printf("Criando...\n");
  printf("Digite o código da turma: ");
  scanf("%d", &idTurma);
  printf("Digite a matéria desse turma: ");
  scanf("%s", materia);
  printf("Digite o número de vagas: ");
  scanf("%d", &vagas);
  printf("Digite o dia da semana que serão as aulas ex:'segunda-feira': ");
  scanf("%s", dia);
  printf("Digite o horário de início da aula ex:'16:00': ");
  scanf("%s", horario);
  printf("Digite a sala da turma ex:'101B': ");
  scanf("%s", sala);
  printf("\n");

  lista = insereUltimoT(lista, listaD, idTurma, vagas, dia, horario, sala, materia);

  return lista;
}
int pegaDadosTuDel(Turma *lista)
{
  int idTur;
  printf("Deletando...\n");
  printf("Digite o código da turma: ");
  scanf("%d", &idTur);
  return idTur;
}

Matricula *pegaDadosMa(Matricula *lista, Aluno *listaA, Turma *listaT)
{
  char data[10];
  int matAluno, idTurma;

  printf("Criando...\n");
  printf("Digite a matrícula do aluno que deseja matricular: ");
  scanf("%d", &matAluno);
  printf("Digite o código da turma que deseja fazer a matrícula: ");
  scanf("%d", &idTurma);
  printf("Digite a data da matrícula ex: dd/mm/aaaa: ");
  scanf("%s", data);
  printf("\n");

  lista = insereUltimoM(lista, listaA, listaT, data, matAluno, idTurma);

  return lista;
}
Matricula *pegaDadosMaDel(Matricula *lista, Turma *listaT)
{
  int matA, idT;

  printf("Deletando...\n");
  printf("Digite o número de matricula do aluno que deseja desmatricular: ");
  scanf("%d", &matA);
  printf("Digite o código da turma que deseja desmatricular o aluno: ");
  scanf("%d", &idT);

  lista = retirarMatricula(lista, listaT, matA, idT);
  return lista;
}

void relatorio1(Matricula *lista)
{
  int cdTurma;
  printf("Digite o código da turma: ");
  scanf("%d", &cdTurma);

  listaAlunosTurma(lista, cdTurma);
}
void relatorio3(Matricula *lista)
{
  int matAlu;

  printf("Digite o número de matrícula do aluno: ");
  scanf("%d", &matAlu);

  contDeDisciplinasAluno(lista, matAlu);
}
void menu()
{
  Aluno *listaA = NULL;
  Turma *listaT = NULL;
  Disciplina *listaD = NULL;
  Matricula *listaM = NULL;
  int escolha, idDisc, idTur, matAl;
  bool fim = false;
  while (fim != true)
  {
    printf("---- Sistema de Matrículas -----\n");
    printf("Escolha uma opção: \n");
    printf("1 - Adicionar um aluno\n");
    printf("2 - Deletar aluno conforme a matrícula\n");
    printf("3 - listar todos alunos cadastrados\n");
    printf("4 - Adicionar uma turma\n");
    printf("5 - Deletar uma turma conforme o código\n");
    printf("6 - Listar todas turmas\n");
    printf("7 - Adicionar uma disciplina\n");
    printf("8 - Deletar disciplina\n");
    printf("9 - Listar disciplinas\n");
    printf("10 - Criar matrícula\n");
    printf("11 - Deletar matrícula\n");
    printf("12 - Listar matrículas\n");
    printf("13 - R1\n");
    printf("14 - R2\n");
    printf("15 - R3\n");
    printf("16 - R4\n");
    printf("17 - R5\n");
    printf("0 - Sair\n");
    printf("Digite o número da opção para ir para a sessão desejada: ");
    scanf("%d", &escolha);
    switch (escolha)
    {
    case 0:
      liberaMa(listaM);
      liberaTu(listaT);
      liberaDi(listaD);
      liberaAl(listaA);
      fim = true;
      break;

    case 1: //add aluno
      listaA = pegaDadosAl(listaA);
      /*listaA = insereUltimoA(listaA, 1, 23, "samu");
      listaA = insereUltimoA(listaA, 2, 13, "samuk");
      listaA = insereUltimoA(listaA, 3, 32, "samuka");
      listaA = insereUltimoA(listaA, 4, 12, "samuel");*/
      break;

    //DELETA ALUNO
    case 2: //del aluno
      matAl = pegaDadosAlDel(listaA);
      listaM = retMatriculaAluno(listaM, matAl);
      listaA = retirarAluno(listaA, matAl);
      break;

    case 3: //list aluno
      listarAluno(listaA);
      break;

    case 4: //add turma
      listaT = pegaDadosTu(listaT, listaD);
      /*listaT = insereUltimoT(listaT, listaD, 1, 10, "segunda-feira", "14:00", "21A", "matematica");
      listaT = insereUltimoT(listaT, listaD, 2, 10, "terça-feira", "14:00", "13A", "etica");
      listaT = insereUltimoT(listaT, listaD, 3, 3, "quarta-feira", "14:00", "22A", "fisica");
      listaT = insereUltimoT(listaT, listaD, 4, 10, "quinta-feira", "14:00", "42A", "matematica");
      listaT = insereUltimoT(listaT, listaD, 5, 10, "sexta-feira", "14:00", "32A", "fisica");
      listaT = insereUltimoT(listaT, listaD, 6, 10, "segunda-feira", "14:00", "21B", "etica");
      listaT = insereUltimoT(listaT, listaD, 7, 3, "terça-feira", "14:00", "21C", "matematica");*/

      break;
    //DELETA TURMA
    case 5: //del turma
      idTur = pegaDadosTuDel(listaT);
      listaM = retMatriculaTurma(listaM, idTur);
      listaT = retirarTurma(listaT, idTur);
      break;

    case 6: //list turma
      listarTurma(listaT);
      break;

    case 7: //add disciplina
      listaD = pegaDadosDi(listaD);
      /*listaD = insereUltimoD(listaD, 1, "matematica", 3);
      listaD = insereUltimoD(listaD, 2, "fisica", 3);
      listaD = insereUltimoD(listaD, 3, "etica", 3);*/
      break;
    //DELETA DISCIPLINA
    case 8: //del disciplina
      idDisc = pegaDadosDiDel(listaD);
      listaM = retMatriculaDisc(listaM, idDisc);
      listaT = retTurmaDisciplina(listaT, idDisc);
      listaD = retirarDisciplina(listaD, idDisc);
      break;

    case 9: //list disciplina
      listarDisciplina(listaD);
      break;

    case 10: //add matricula
      /*listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 1, 1);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 1, 2);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 1, 3);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 2, 2);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 2, 3);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 2, 1);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 3, 1);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 3, 2);
      listaM = insereUltimoM(listaM, listaA, listaT, "19/05/2020", 3, 3);*/
      listaM = pegaDadosMa(listaM, listaA, listaT);
      break;

    case 11: //del matricula
      listaM = pegaDadosMaDel(listaM, listaT);
      break;

    case 12: //list matricula
      listarMatricula(listaM);
      break;

    case 13: //R1
      relatorio1(listaM);
      break;

    case 14: //R2
      contDeTurmasDisciplinas(listaD);
      break;

    case 15: //R3
      relatorio3(listaM);
      break;

    case 16: //R4
      contAlunosTurma(listaT);
      break;

    case 17: //R5
      listaTurmaLot(listaT);
      break;

    default:
      printf("Opção inválida.\n");
      break;
    }
  }
}