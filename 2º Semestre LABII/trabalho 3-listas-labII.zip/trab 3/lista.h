struct ListaAluno
{
  int matricula;
  int telefone;
  char nome[30];
  struct ListaAluno *proximo;
};

struct ListaTurma
{
  int idTurma;
  struct ListaDisciplina *materia;
  int vagas;
  int vagasOcupadas;
  char dia[15];
  char horario[6];
  char sala[10];
  struct ListaTurma *proximo;
};

struct ListaDisciplina
{
  int idDisciplina;
  char nome[70];
  int creditos;
  int contTurmas;
  struct ListaDisciplina *proximo;
};

struct ListaMatricula
{
  struct ListaAluno *aluno;
  struct ListaTurma *turma;
  char data[10];
  struct ListaMatricula *proximo;
};

typedef struct ListaAluno Aluno;
typedef struct ListaTurma Turma;
typedef struct ListaDisciplina Disciplina;
typedef struct ListaMatricula Matricula;

//alunos
Aluno *criarAluno();
Aluno *insereUltimoA(Aluno *lista, int matricula, int telefone, char nome[30]);
void listarAluno(Aluno *lista);
Aluno *retirarAluno(Aluno *lista, int matricula);
void liberaAl(Aluno *lista);

//disciplina
Disciplina *criarDisciplina();
Disciplina *insereUltimoD(Disciplina *lista, int idDisciplina, char nome[70], int creditos);
void listarDisciplina(Disciplina *lista);
Disciplina *retirarDisciplina(Disciplina *lista, int id);
void contDeTurmasDisciplinas(Disciplina *lista);
void liberaDi(Disciplina *lista);

//turma

Turma *criarTurma();
Turma *insereUltimoT(Turma *lista, Disciplina *listaD, int idTurma, int vagas, char dia[15], char horario[6], char sala[10], char disciplina[40]);
void listarTurma(Turma *lista);
Turma *retirarTurma(Turma *lista, int idTurma);
void contAlunosTurma(Turma *lista);
void liberaTu(Turma *lista);
Turma *retTurmaDisciplina(Turma *lista, int idDisc);

//matricula

Matricula *criarMatricula();
Matricula *insereUltimoM(Matricula *lista, Aluno *listaA, Turma *listaT, char data[10], int matAluno, int idTurma);
void listarMatricula(Matricula *lista);
Matricula *retirarMatricula(Matricula *lista, Turma *listaT, int matAluno, int idTurma);
void listaAlunosTurma(Matricula *lista, int idTurma);
void contDeDisciplinasAluno(Matricula *lista, int matAluno);
void listaTurmaLot(Turma *lista);
void liberaMa(Matricula *lista);
Matricula *retMatriculaDisc(Matricula *lista, int idDisc);
Matricula *retMatriculaTurma(Matricula *lista, int idTur);
Matricula *retMatriculaAluno(Matricula *lista, int matAl);