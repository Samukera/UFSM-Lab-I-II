#include "lista.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

Aluno *criarAluno()
{
  Aluno *aluno = (Aluno *)malloc(sizeof(Aluno));
  return aluno;
}
Aluno *insereUltimoA(Aluno *lista, int matricula, int telefone, char nome[30])
{
  Aluno *alunoN = criarAluno();
  alunoN->matricula = matricula;
  alunoN->telefone = telefone;
  strcpy(alunoN->nome, nome);

  if (lista == NULL)
  {
    alunoN->proximo = NULL;
    lista = alunoN;
  }
  else
  {
    Aluno *aux = lista;
    while (aux->proximo != NULL)
    {
      aux = aux->proximo;
    }
    alunoN->proximo = NULL;
    aux->proximo = alunoN;
  }
  printf("\nInserção feita com sucesso.\n");
  return lista;
}
void listarAluno(Aluno *lista)
{
  Aluno *aux = lista;

  printf("Listando...\n");

  if (aux == NULL)
  {
    printf("lista vazia.\n");
  }
  else
  {
    while (aux != NULL)
    {
      printf("\nAluno %s , telefone: %d, matricula: %d\n", aux->nome, aux->telefone, aux->matricula);
      aux = aux->proximo;
    }
  }
}
Aluno *retirarAluno(Aluno *lista, int matricula)
{
  Aluno *aux = lista;
  Aluno *antes = NULL;

  while (aux != NULL && aux->matricula != matricula)
  {
    antes = aux;
    aux = aux->proximo;
  }
  if (aux == NULL)
  {
    printf("\nAluno não encontrado.\n");
    return lista;
  }
  if (antes == NULL)
  {
    lista = aux->proximo;
  }
  else
  {
    antes->proximo = aux->proximo;
  }
  free(aux);
  printf("\nAluno retirado com sucesso.\n");
  return lista;
}
void liberaAl(Aluno *lista)
{
  Aluno *aux = lista;

  while (aux != NULL)
  {
    Aluno *prox = aux->proximo;
    free(aux);
    aux = prox;
  }
}

Disciplina *criarDisciplina()
{
  Disciplina *disciplina = (Disciplina *)malloc(sizeof(Disciplina));
  return disciplina;
}
Disciplina *insereUltimoD(Disciplina *lista, int idDisciplina, char nome[70], int creditos)
{
  Disciplina *disciplinaN = criarDisciplina();
  disciplinaN->idDisciplina = idDisciplina;
  strcpy(disciplinaN->nome, nome);
  disciplinaN->creditos = creditos;
  disciplinaN->contTurmas = 0;

  if (lista == NULL)
  {
    disciplinaN->proximo = NULL;
    lista = disciplinaN;
  }
  else
  {
    Disciplina *aux = lista;
    while (aux->proximo != NULL)
    {
      aux = aux->proximo;
    }
    disciplinaN->proximo = NULL;
    aux->proximo = disciplinaN;
  }
  printf("\nInserção feita com sucesso.\n");
  return lista;
}
void listarDisciplina(Disciplina *lista)
{
  Disciplina *aux = lista;

  printf("Listando...\n");

  if (aux == NULL)
  {
    printf("lista vazia.\n");
  }
  else
  {
    while (aux != NULL)
    {
      printf("\nDisciplina %s , seu id: %d , créditos %d.\n", aux->nome, aux->idDisciplina, aux->creditos);
      aux = aux->proximo;
    }
  }
}
Disciplina *retirarDisciplina(Disciplina *lista, int id)
{
  Disciplina *aux = lista;
  Disciplina *antes = NULL;

  while (aux != NULL && aux->idDisciplina != id)
  {
    antes = aux;
    aux = aux->proximo;
  }
  if (aux == NULL)
  {
    printf("\nDisciplina não encontrada.\n");
    return lista;
  }
  if (antes == NULL)
  {
    lista = aux->proximo;
  }
  else
  {
    antes->proximo = aux->proximo;
  }
  free(aux);
  printf("\nDisciplina retirada com sucesso.\n");
  return lista;
}
void liberaDi(Disciplina *lista)
{
  Disciplina *aux = lista;

  while (aux != NULL)
  {
    Disciplina *prox = aux->proximo;
    free(aux);
    aux = prox;
  }
}

Turma *criarTurma()
{
  Turma *turma = (Turma *)malloc(sizeof(Turma));
  return turma;
}
Turma *insereUltimoT(Turma *lista, Disciplina *listaD, int idTurma, int vagas, char dia[15], char horario[6], char sala[10], char disciplina[40])
{
  int prova;
  while (listaD != NULL)
  {
    prova = strcmp(disciplina, listaD->nome);
    if (prova == 0)
    {
      Turma *turmaN = criarTurma();
      turmaN->idTurma = idTurma;
      turmaN->vagas = vagas;
      turmaN->vagasOcupadas = 0;
      turmaN->materia = listaD;
      strcpy(turmaN->dia, dia);
      strcpy(turmaN->horario, horario);
      strcpy(turmaN->sala, sala);
      listaD->contTurmas++;

      if (lista == NULL)
      {
        turmaN->proximo = NULL;
        lista = turmaN;
      }
      else
      {
        Turma *aux = lista;
        while (aux->proximo != NULL)
        {
          aux = aux->proximo;
        }
        turmaN->proximo = NULL;
        aux->proximo = turmaN;
      }
      printf("\nTurma inserida com sucesso.\n");
    }
    listaD = listaD->proximo;
  }
  return lista;
}
void listarTurma(Turma *lista)
{
  Turma *aux = lista;

  printf("Listando...\n");

  if (aux == NULL)
  {
    printf("lista vazia.\n");
  }
  else
  {
    while (aux != NULL)
    {
      printf("\nturma - %d, vagas - %d, dia - %s, horário - %s, sala - %s, disciplina da turma - %s\n", aux->idTurma, aux->vagas, aux->dia, aux->horario, aux->sala, aux->materia->nome);
      aux = aux->proximo;
    }
  }
}
Turma *retirarTurma(Turma *lista, int idTurma)
{
  Turma *aux = lista;  //ponteiro para o elemento anterior
  Turma *antes = NULL; //ponteiro para percorrer a lista

  //procura o elemento na lista, guardando o elemento anterior
  while (aux != NULL && aux->idTurma != idTurma)
  {
    antes = aux;
    aux = aux->proximo;
  }
  //verifica se achou o elemento
  if (aux == NULL)
  {
    printf("\nTurma não encontrada.\n");
    return lista; //lista original, nao achou.
  }
  //retira elemento
  if (antes == NULL)
  {
    //caso 1 - elemento encontrado é o primeiro da lista, passa o cabeça para o próximo
    lista = aux->proximo;
  }
  else
  {
    //caso 2 - o elemento está no meio da lista, o ponteiro anterior aponta pro seguinte em relação ao que queremos remover.
    antes->proximo = aux->proximo;
  }
  free(aux);
  printf("\nTurma retirada com sucesso.\n");
  return lista;
}
void liberaTu(Turma *lista)
{
  Turma *aux = lista;

  while (aux != NULL)
  {
    Turma *prox = aux->proximo;
    free(aux);
    aux = prox;
  }
}
Turma *retTurmaDisciplina(Turma *lista, int idDisc)
{
  Turma *aux = lista;
  Turma *anterior = NULL;
  while (aux != NULL)
  {
    if (aux->materia->idDisciplina == idDisc)
    {
      if (anterior == NULL)
        lista = aux->proximo;
      else
        anterior->proximo = aux->proximo;
      free(aux);
    }
    else
    {
      anterior = aux;
    }
    aux = aux->proximo;
  }
  return lista;
}

Matricula *criarMatricula()
{
  Matricula *matricula = (Matricula *)malloc(sizeof(Matricula));
  return matricula;
}
Matricula *insereUltimoM(Matricula *lista, Aluno *listaA, Turma *listaT, char data[20], int matAluno, int idTurma)
{
  Aluno *auxA = listaA;
  while (auxA != NULL)
  {
    if (matAluno == auxA->matricula)
    {
      Turma *auxT = listaT;
      while (auxT != NULL)
      {
        if (idTurma == auxT->idTurma && auxT->vagasOcupadas < auxT->vagas)
        {
          Matricula *matriculaN = criarMatricula();

          matriculaN->aluno = auxA;
          matriculaN->turma = auxT;
          auxT->vagasOcupadas++;
          strcpy(matriculaN->data, data);

          if (lista == NULL)
          {
            matriculaN->proximo = NULL;
            lista = matriculaN;
          }
          else
          {
            Matricula *aux = lista;
            while (aux->proximo != NULL)
            {
              aux = aux->proximo;
            }
            matriculaN->proximo = NULL;
            aux->proximo = matriculaN;
          }
          printf("\nMatricula Inserida com sucesso.\n");
        }
        auxT = auxT->proximo;
      }
    }
    auxA = auxA->proximo;
  }
  return lista;
}
void listarMatricula(Matricula *lista)
{
  Matricula *aux = lista;

  printf("Listando...\n");

  if (aux == NULL)
  {
    printf("lista vazia de matrícula.\n");
  }
  else
  {
    while (aux != NULL)
    {
      printf("\nAluno - %s, matricula - %d, turma - %s, código da turma - %d, data - %s\n", aux->aluno->nome, aux->aluno->matricula, aux->turma->materia->nome, aux->turma->idTurma, aux->data);
      aux = aux->proximo;
    }
  }
}
Matricula *retirarMatricula(Matricula *lista, Turma *listaT, int matAluno, int idTurma)
{
  Matricula *aux = lista;
  Matricula *antes = NULL;

  while (aux != NULL && (aux->aluno->matricula != matAluno || aux->turma->idTurma != idTurma))
  {
    antes = aux;
    aux = aux->proximo;
  }
  if (aux == NULL)
  {
    printf("\nMatrícula não encontrada\n.");
    return lista;
  }
  if (antes == NULL)
  {
    lista = aux->proximo;
  }
  else
  {
    antes->proximo = aux->proximo;
  }
  free(aux);

  while (listaT != NULL)
  {
    if (listaT->idTurma == idTurma)
    {
      break;
    }
    else
    {
      listaT = listaT->proximo;
    }
  }
  listaT->vagasOcupadas--;
  printf("\nMatrícula retirada com sucesso.\n");

  return lista;
}
void liberaMa(Matricula *lista)
{
  Matricula *aux = lista;

  while (aux != NULL)
  {
    Matricula *prox = aux->proximo;
    free(aux);
    aux = prox;
  }
}
Matricula *retMatriculaDisc(Matricula *lista, int idDisc)
{
  Matricula *aux = lista;
  Matricula *anterior = NULL;
  while (aux != NULL)
  {
    if (aux->turma->materia->idDisciplina == idDisc)
    {
      if (anterior == NULL)
        lista = aux->proximo;
      else
        anterior->proximo = aux->proximo;
      free(aux);
    }
    else
    {
      anterior = aux;
    }
    aux = aux->proximo;
  }
  return lista;
}
Matricula *retMatriculaTurma(Matricula *lista, int idTur)
{
  Matricula *aux = lista;
  Matricula *anterior = NULL;
  while (aux != NULL)
  {
    if (aux->turma->idTurma == idTur)
    {
      if (anterior == NULL)
        lista = aux->proximo;
      else
        anterior->proximo = aux->proximo;
      free(aux);
    }
    else
    {
      anterior = aux;
    }
    aux = aux->proximo;
  }
  return lista;
}
Matricula *retMatriculaAluno(Matricula *lista, int matAl)
{
  Matricula *aux = lista;
  Matricula *anterior = NULL;
  while (aux != NULL)
  {
    if (aux->aluno->matricula == matAl)
    {
      aux->turma->vagasOcupadas--;
      if (anterior == NULL)
        lista = aux->proximo;
      else
        anterior->proximo = aux->proximo;
      free(aux);
    }
    else
    {
      anterior = aux;
    }
    aux = aux->proximo;
  }
  return lista;
}

//R1
void listaAlunosTurma(Matricula *lista, int idTurma)
{
  Matricula *aux = lista;
  printf("\nR1 - A lista nominal dos alunos matriculados em certa turma\n");
  printf("\nAlunos matrículados nessa turma:\n");
  while (aux != NULL)
  {
    if (aux->turma->idTurma == idTurma)
    {
      printf("\nNome: %s - Matricula: %d\n", aux->aluno->nome, aux->aluno->matricula);
    }
    aux = aux->proximo;
    printf("\n");
  }
}
//R2
void contDeTurmasDisciplinas(Disciplina *lista)
{
  Disciplina *aux = lista;
  printf("\nR2 - Para cada disciplina cadastrada, informe quantas turmas existem\n");
  printf("\nDisciplinas e número de turmas\n");
  while (aux != NULL)
  {
    printf("\nDisciplina: %s - Número de turmas: %d\n", aux->nome, aux->contTurmas);
    aux = aux->proximo;
  }
  printf("\n");
}
//R3
void contDeDisciplinasAluno(Matricula *lista, int matAluno)
{
  Matricula *aux = lista;
  printf("\nR3 - O nome das disciplinas que certo aluno está cursando\n");
  printf("\nAluno - %d está cursando: \n", matAluno);
  while (aux != NULL)
  {
    if (aux->aluno->matricula == matAluno)
    {
      printf("\nDisciplina: %s\n", aux->turma->materia->nome);
    }
    aux = aux->proximo;
  }
  printf("\n");
}
//R4
void contAlunosTurma(Turma *lista)
{
  Turma *aux = lista;
  printf("\nR4 -  A quantidade de alunos matriculados em cada turma\n");
  printf("\nTurmas: \n");
  while (aux != NULL)
  {
    printf("\nCódigo da turma - %d - Turma: %s - Quantidade de Alunos - %d\n", aux->idTurma, aux->materia->nome, aux->vagasOcupadas);
    aux = aux->proximo;
  }
  printf("\n");
}
//R5
void listaTurmaLot(Turma *lista)
{
  Turma *aux = lista;
  printf("\nR5 - O código das turmas que estão lotadas (todas as vagas oferecidas foram preenchidas)\n");
  printf("Turmas lotadas: \n");
  while (aux != NULL)
  {
    int vagas = aux->vagas;
    int vagasOcup = aux->vagasOcupadas;
    if (vagasOcup == vagas)
    {
      printf("\nCódigo da Turma - %d\n", aux->idTurma);
    }
    aux = aux->proximo;
    printf("\n");
  }
}