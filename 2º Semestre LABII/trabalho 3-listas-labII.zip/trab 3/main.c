#include "menu.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main()
{
  menu();
}