#include "lista.h"
void menu();

Aluno *pegaDadosAl(Aluno *lista);
int pegaDadosAlDel(Aluno *lista);

Turma *pegaDadosTu(Turma *lista, Disciplina *listaD);
int pegaDadosTuDel(Turma *lista);

Disciplina *pegaDadosDi(Disciplina *lista);
int pegaDadosDiDel(Disciplina *lista);

Matricula *pegaDadosMa(Matricula *lista, Aluno *listaA, Turma *listaT);
Matricula *pegaDadosMaDel(Matricula *lista, Turma *listaT);

//R1 R3
void relatorio1(Matricula *lista);

void relatorio3(Matricula *lista);
