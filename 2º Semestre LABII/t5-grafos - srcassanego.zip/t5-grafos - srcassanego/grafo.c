#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"

Grafo* cria_grafo(int nVertices, int grau_max, int ponderado){
    Grafo *gr = (Grafo*) malloc(sizeof(struct grafo));
    
    if(gr != NULL){
        int i;

        gr->nroVertices = nVertices;
        gr->grauMax = grau_max;
        gr->ehPonderado = (ponderado != 0)?1:0;
        gr->grau = (int*) calloc (nVertices,sizeof(int));
        gr->arestas = (int**) malloc(nVertices*sizeof(int*));
        for(i = 0; i < nVertices; i++){
            gr->arestas[i] = (int*) malloc(grau_max*sizeof(int));
            if(gr->ehPonderado)
            {
                gr->pesos=(float**)malloc(nVertices*sizeof(float*));

                for(i = 0; i < nVertices;i++){
                    gr->pesos[i] = (float*) malloc(grau_max*sizeof(float));
                }
            }
        }
    }
    return gr;
}

int insereAresta(Grafo* gr, int origem, int dest, int digrafo, float peso){
    if(gr == NULL){
        return 0;
    }
    if(origem < 0 || origem >= gr->nroVertices){
        return 0;
    }
    if(dest < 0 || dest >= gr->nroVertices){
        return 0;
    }

    gr->arestas[origem][gr->grau[origem]] = dest;
    if(gr->ehPonderado){
        gr->pesos[origem][gr->grau[origem]] = peso;
    }
    gr->grau[origem]++;

    if(digrafo == 0){
        insereAresta(gr,dest,origem,1,peso);
    }
    return 1;

}

int removeAresta(Grafo* gr, int origem, int dest, int eh_digrafo){
    if(gr == NULL){
        return 0;
    }
    if(origem < 0 || origem >= gr->nroVertices){
        return 0;
    }
    if(dest < 0 || dest >= gr->nroVertices){
        return 0;
    }

    int i = 0;
    
    while(i < gr->grau[origem] && gr->arestas[origem][i] != dest){
        i++;
    }
    if(i == gr->grau[origem]){//elemento não encontrado.
        return 0;    
    }
    gr->grau[origem]--;
    gr->arestas[origem][i] = gr->arestas[origem][gr->grau[origem]];
    if(gr->ehPonderado){
        gr->pesos[origem][i] = gr->pesos[origem][gr->grau[origem]];
    }
    if(eh_digrafo == 0){
        removeAresta(gr,dest,origem,1);
    }
    return 1;
}

int procuraMenorDistancia(float *dist, int* visitado, int nv){
    int i, menor = -1, primeiro = 1;

    for(i = 0; i < nv; i++){
        if(dist[i] >= 0 && visitado[i] == 0){
            if(primeiro){
                menor = i;
                primeiro = 0;
            }else{
                if(dist[menor] > dist[i]){
                    menor = i;
                }
            }
        }
    }
    return menor;
}

void dijkstra(Grafo *gr, int ini, int *ant, float *dist){
    int i, cont, nv, ind, *visitado, u;
    nv = gr->nroVertices;
    cont = nv;
    visitado = (int*) malloc(nv * sizeof(int));

    for(i = 0; i < nv; i++){
        ant[i] = -1;
        dist[i] = -1;
        visitado[i] = 0;
    }
    dist[ini] = 0;
    while(cont > 0){
        u = procuraMenorDistancia(dist, visitado, nv);

        if(u == -1){
            break;
        }
        visitado[u] = 1;
        cont--;
        
        for(i = 0; i < gr->grau[u]; i++){
            ind = gr->arestas[u][i];
            if(dist[ind] < 0){
                dist[ind] = dist[u] + 1;
                ant[ind] = u;
            }else{
                if(dist[ind] > dist[u] + 1){
                    dist[ind] = dist[u] + 1;
                    ant[ind] = u;
                }
            }
        }

    }
    free(visitado);
}


void libera_Grafo(Grafo* gr){
    if(gr != NULL){
        int i;
        for(i=0; i < gr->nroVertices; i++){
            free(gr->arestas[i]);
        }
        free(gr->arestas);
        
        if(gr->ehPonderado){
            for(i = 0; i < gr->nroVertices; i++){
                free(gr->pesos[i]);
            }
            free(gr->pesos);
        }
        free(gr->grau);
        free(gr);
    }
}

int main(){
    //criando grafo
    Grafo *gr;
    gr = cria_grafo(10,10,0);
    //Programa principal
    insereAresta(gr,0,1,1,6);
    insereAresta(gr,1,2,1,5);
    insereAresta(gr,1,3,1,1);
    insereAresta(gr,2,4,1,2);
    insereAresta(gr,2,3,1,0);
    insereAresta(gr,2,5,1,7);
    insereAresta(gr,2,1,1,4);
    insereAresta(gr,3,1,1,2);
    insereAresta(gr,3,6,1,2);
    insereAresta(gr,3,2,1,2);
    insereAresta(gr,3,5,1,2);
    insereAresta(gr,4,2,1,3);
    insereAresta(gr,4,5,1,3);
    insereAresta(gr,4,7,1,3);
    insereAresta(gr,5,2,1,4);
    insereAresta(gr,5,3,1,4);
    insereAresta(gr,5,6,1,3);
    insereAresta(gr,5,4,1,2);
    insereAresta(gr,5,7,1,1);
    insereAresta(gr,5,8,1,3);
    insereAresta(gr,6,3,1,2);
    insereAresta(gr,6,5,1,2);
    insereAresta(gr,6,8,1,1);
    insereAresta(gr,7,4,1,1);
    insereAresta(gr,7,5,1,1);
    insereAresta(gr,7,9,1,0);
    insereAresta(gr,8,6,1,1);
    insereAresta(gr,8,5,1,1);
    insereAresta(gr,8,9,1,2);
    insereAresta(gr,9,8,1,1);
    insereAresta(gr,9,7,1,4);



    
    
    int ant[10];
    float dist[10];
    dijkstra(gr,0,ant,dist);

    libera_Grafo(gr);


}