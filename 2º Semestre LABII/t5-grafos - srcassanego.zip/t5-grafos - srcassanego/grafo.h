struct grafo
{
    int ehPonderado;
    int nroVertices;
    int grauMax;
    int** arestas;
    float** pesos;
    int* grau;
};

typedef struct grafo Grafo;

Grafo* cria_grafo(int nVertices, int grau_max, int ponderado);
void libera_Grafo(Grafo* gr);
int insereAresta(Grafo* gr, int origem, int dest, int digrafo, float peso);
int removeAresta(Grafo* gr, int origem, int dest, int digrafo);
void dijkstra(Grafo *gr, int ini, int *ant, float *dist);
int procuraMenorDistancia(float *dist, int *visitado, int nv);