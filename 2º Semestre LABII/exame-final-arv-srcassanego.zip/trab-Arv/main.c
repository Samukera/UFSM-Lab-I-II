//Nome do aluno: Samuel Rech Cassanego
//Exame Final - Árvore Binária de Busca - Armazenamento de dados das cidades sobre o COVID-19
#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"
#include <stdbool.h>
#include <string.h>

int main()
{
  Arv *a = criaArv();
  Arv *aux = NULL;

  bool acabou = false;
  int sn;
  char municipio[25];

  while (acabou != true)
  {
    aux = a;
    printf("\n### MENU ###\n");
    printf("1 - Cadastrar município\n");
    printf("2 - Deletar município\n");
    printf("3 - Listar dados\n");
    printf("4 - Buscar município e seus dados\n");
    printf("5 - Inserir dados ao municipio\n");
    printf("6 - Sair\nEscolha: ");
    scanf("%d", &sn);

    switch (sn)
    {
    case 1:
      printf("\nInserindo...\n");
      a = cadastraMunicipio(a);
      break;

    case 2:
      //Deletar dados;
      printf("\nDeletando...\n");
      printf("Município: ");
      scanf(" %[^\n]s ", municipio);

      a = retira(a, municipio);

      break;

    case 3:
      //Listar dados;
      printf("\n### Listagem ###\n");
      imprimeEmOrdem(aux);

      break;

    case 4:
      //Buscar dados;
      printf("Município: ");
      scanf(" %[^\n]s ", municipio);
      printf("\nBuscando...\n\n");

      aux = buscaEmArv(aux, municipio);
      imprimeNo(aux);
      break;

    case 5:
      //inseir dados ao municipio;
      printf("Município: ");
      scanf(" %[^\n]s ", municipio);

      // passo a passo
      //1º buscar o munícipio cadastrado na árvore.
      aux = buscaEmArv(aux, municipio);
      //retorna o nó do municipio chamado
      //2º inserir os dados.
      if (aux == NULL)
      {
        printf("\nMunicípio não pertencente ao sistema.\n");
      }
      else
      {
        aux = cadastraDadosEpi(aux, aux->dados->dia, municipio); //envia para a função onde são pedidos os dados para se inserir no campo do município.
      }
      break;

    case 6:
      acabou = true;
      printf("\nPrograma encerrado...\n");
      break;

    default:
      printf("\nOpção inválida.\n");
      break;
    }
  }
}