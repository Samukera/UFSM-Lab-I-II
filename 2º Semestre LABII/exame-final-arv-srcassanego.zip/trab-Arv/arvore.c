#include "arvore.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Imprime a lista de municípios com seus dados epidemiologicos calculados
void imprimeEmOrdem(Arv *a)
{
  if (a != NULL)
  {
    int totalConfirmados, totalObitos, ultConfirmado, ultObito;
    float incidencia, mortalidade, populac;

    totalConfirmados = totalObitos = 0;
    populac = a->populacao;

    imprimeEmOrdem(a->dir);
    printf("####\nMunicípio: %s\n", a->municipio);
    Dados *dados = a->dados;
    while (dados != NULL)
    {
      totalConfirmados = totalConfirmados + dados->novosConfirmados;
      totalObitos = totalObitos + dados->novosObitos;
      incidencia = totalConfirmados / (populac / 100000);
      mortalidade = totalObitos / (populac / 100000);

      if (dados->prox == NULL)
      {
        ultConfirmado = dados->novosConfirmados;
        ultObito = dados->novosObitos;
      }
      dados = dados->prox;
    }
    printf("Total de confirmados: %d \nÚltimos novos confirmados: %d\nIncidência por 100 mil habitantes: %.2f\nTotal de óbitos: %d\nÚltimos novos óbitos: %d\nMortalidade por 100 mil habitantes: %.2f\n", totalConfirmados, ultConfirmado, incidencia, totalObitos, ultObito, mortalidade);
    imprimeEmOrdem(a->esq);
  }
}
//Imprime o município com o histórico de dados de cada dia
void imprimeNo(Arv *a)
{
  if (a != NULL)
  {
    printf("Município: %s \n População: %d \n", a->municipio, a->populacao);
    Dados *dados = a->dados;
    while (dados != NULL)
    {
      printf("\n## Dia do vírus: %d ##\n Confirmados no dia: %d \n Obitos no dia: %d \n", dados->dia, dados->novosConfirmados, dados->novosObitos);
      dados = dados->prox;
    }
  }
}
//Cria a árvore
Arv *criaArv()
{
  return NULL;
}
//Cadastra o município na sua árvore e insere dados epidemiologicos
Arv *cadastraMunicipio(Arv *a) // tópico 1 do menu.
{
  char municipio[25];
  int populacao;
  int novosConfirmados;
  int novosObitos;
  int dia = 1;
  int exit = 1;

  printf("Preencha os dados: \n");
  printf("Município: ");
  scanf(" %[^\n]s ", municipio);
  printf("População: ");
  scanf("%d", &populacao);
  setbuf(stdin, NULL);

  a = insereMuni(a, municipio, populacao);

  Arv *aux = a;
  Dados *list = NULL;
  aux = buscaEmArv(a, municipio);

  while (exit != 0)
  {
    printf("Dia %d:\n", dia);
    printf("Casos confirmados: ");
    scanf("%d", &novosConfirmados);
    printf("Óbitos: ");
    scanf("%d", &novosObitos);

    list = insere(list, dia, novosConfirmados, novosObitos);

    printf("\n Deseja adicionar dados dos próximos dias? (Sim = 1 || Não = 0)\n");
    scanf("%d", &exit);
    dia = dia + 1;

    if (exit > 1 || exit < 0)
    {
      printf("Opção inválida.\n");
      exit = 0;
    }
  }
  aux->dados = list;

  return a;
}
//Cadastra dados epidemiologicos
Arv *cadastraDadosEpi(Arv *a, int dia, char municipio[]) // tópico 5 do menu.
{
  int novosConfirmados;
  int novosObitos;
  int exit = 1;

  Arv *aux = a;
  aux = buscaEmArv(a, municipio);
  Dados *listaD = aux->dados;
  Dados *suporte;

  while (exit != 0)
  {
    dia = 1;
    suporte = listaD;
    if (suporte != NULL)
    {
      while (suporte != NULL)
      {
        dia = dia + 1;
        suporte = suporte->prox;
      }
    }

    printf("Dia %d:\n", dia);
    printf("Casos confirmados: ");
    scanf("%d", &novosConfirmados);
    printf("Óbitos: ");
    scanf("%d", &novosObitos);

    listaD = insere(listaD, dia, novosConfirmados, novosObitos);

    printf("\n Deseja adicionar dados dos próximos dias? (Sim = 1 || Não = 0) \n");
    scanf("%d", &exit);
    dia += 1;

    if (exit > 1 || exit < 0)
    {
      printf("Opção inválida.\n");
      exit = 0;
    }
  }
  aux->dados = listaD;

  return a;
}
//Busca município na árvore
Arv *buscaEmArv(Arv *a, char municipio[])
{
  if (a == NULL)
  {
    printf("\nMunicípio não encontrado.\n");
    return NULL;
  }
  else if (strcmp(a->municipio, municipio) < 0)
  {
    return buscaEmArv(a->esq, municipio);
  }
  else if (strcmp(a->municipio, municipio) > 0)
  {
    return buscaEmArv(a->dir, municipio);
  }
  else
  {
    return a;
  }
}

//usar para inserir os dados epidemiologicos;
Dados *insere(Dados *dados, int dia, int novosConfirmados, int novosObitos)
{
  Dados *novoNo = (Dados *)malloc(sizeof(Dados));
  novoNo->dia = dia;
  novoNo->novosConfirmados = novosConfirmados;
  novoNo->novosObitos = novosObitos;

  if (dados == NULL)
  {
    novoNo->prox = NULL;
    dados = novoNo;
  }
  else
  {
    Dados *aux = dados;
    while (aux->prox != NULL)
    {
      aux = aux->prox;
    }
    novoNo->prox = NULL;
    aux->prox = novoNo;
  }

  return dados;
}
//Insere o Municipio e população na árvore
Arv *insereMuni(Arv *a, char municipio[], int populacao)
{
  if (a == NULL)
  {
    a = (Arv *)malloc(sizeof(Arv));
    a->populacao = populacao;
    strcpy(a->municipio, municipio);

    a->esq = a->dir = NULL;
  }
  //strcmp - para verificar se vai para a direita ou esquerda em ordem alfabética.
  else if (strcmp(a->municipio, municipio) < 0) //se '< 0' o município existente é menor do que o novo, então vai para a esquerda
  {
    a->esq = insereMuni(a->esq, municipio, populacao);
  }
  else if (strcmp(a->municipio, municipio) > 0) //se '> 0' o município existente é maior do que o novo, então vai para a direta
  {
    a->dir = insereMuni(a->dir, municipio, populacao);
  }

  return a;
}
//Deleta o nó da árvore
Arv *retira(Arv *r, char municipio[])
{
  if (r == NULL)
  {
    printf("\nMunicípio não existe no sistema\n");
    return NULL;
  }
  else if (strcmp(r->municipio, municipio) < 0)
  {
    r->esq = retira(r->esq, municipio);
  }
  else if (strcmp(r->municipio, municipio) > 0)
  {
    r->dir = retira(r->dir, municipio);
  }
  else //achou o nó
  {
    //nó sem filhos
    if (r->esq == NULL && r->dir == NULL)
    {
      free(r);
      r = NULL;
    }

    //nó com filhos na direita
    else if (r->esq == NULL)
    {
      Arv *t = r;
      r = r->dir;
      free(t);
    }
    //só tem filho à esquerda
    else if (r->dir == NULL)
    {
      Arv *t = r;
      r = r->esq;
      free(t);
    }
    //nó tem os dois filhos
    else
    {
      Arv *f = r->esq;
      while (f->dir != NULL)
      {
        f = f->dir;
      }
      strcpy(r->municipio, f->municipio); //troca informações.
      r->populacao = f->populacao;
      r->dados = f->dados;
      strcpy(f->municipio, municipio);
      r->esq = retira(r->esq, municipio);
    }
  }
  return r;
}
