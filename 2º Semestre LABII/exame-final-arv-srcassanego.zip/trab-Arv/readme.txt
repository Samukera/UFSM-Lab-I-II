Código feito por: Samuel Rech Cassanego

Exame-final: Trabalho de ABB envolvendo dados do COVID-19

Compilar via terminal gcc: gcc -Wall main.c arvore.c -o main
