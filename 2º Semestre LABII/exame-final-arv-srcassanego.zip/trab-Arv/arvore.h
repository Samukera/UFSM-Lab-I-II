//Struct para guardar os dados epidemiológicos
struct noDados
{
  int dia;
  int novosConfirmados;
  int novosObitos;
  struct noDados *prox;
};
typedef struct noDados Dados;
//Struct árvore
struct noArv
{
  char municipio[25];
  int populacao;
  struct noDados *dados;
  struct noArv *esq;
  struct noArv *dir;
};
typedef struct noArv Arv;

void imprimeEmOrdem(Arv *a); //Faz a listagem dos dados epidemiológicos de todos municípios cadastrados
void imprimeNo(Arv *a);      //Faz a listagem dos dados de cada dia de um município em específico

Arv *retira(Arv *r, char municipio[]);                    //Remove nó da árvore
Arv *criaArv();                                           //Cria árvore
Arv *cadastraMunicipio(Arv *a);                           //Recebe o futuro nó e seus dados da árvore
Arv *buscaEmArv(Arv *a, char municipio[]);                //Busca o nó na árvore através do município
Arv *insereMuni(Arv *a, char municipio[], int populacao); // Insere os dados na árvore (município, população)

Dados *insere(Dados *dados, int dia, int novosConfirmados, int novosObitos); //Insere os dados epidemiológicos no campo dados da struct árvore
Arv *cadastraDadosEpi(Arv *a, int dia, char municipio[]);                    //Recebe os dados epidemiológicos para inserir no campo dados do município desejado