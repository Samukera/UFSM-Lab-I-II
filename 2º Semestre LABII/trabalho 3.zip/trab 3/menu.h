#include "lista.h"
void menu();

Aluno *pegaDadosAl(Aluno *lista);
//Aluno *pegaDadosAlDel(Aluno *lista);

Turma *pegaDadosTu(Turma *lista, Disciplina *listaD);
//Turma *pegaDadosTuDel(Turma *lista);

Disciplina *pegaDadosDi(Disciplina *lista);
//Disciplina *pegaDadosDiDel(Disciplina *lista);

Matricula *pegaDadosMa(Matricula *lista, Aluno *listaA, Turma *listaT);
//Matricula *pegaDadosMaDel(Matricula *lista);

//R1 R3
void relatorio1(Matricula *lista);

void relatorio3(Matricula *lista);
