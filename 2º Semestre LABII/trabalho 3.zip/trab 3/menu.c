#include "menu.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

Aluno *pegaDadosAl(Aluno *lista)
{
  int telefone, matriculaAluno;
  char nomeAluno[30];

  printf("Criando...\n");
  printf("Digite o nome do aluno: ");
  scanf("%s", nomeAluno);
  printf("Digite o número de matrícula do aluno: ");
  scanf("%d", &matriculaAluno);
  printf("Digite o número de telefone do aluno: ");
  scanf("%d", &telefone);

  lista = insereUltimoA(lista, matriculaAluno, telefone, nomeAluno);

  return lista;
}
Aluno *pegaDadosAlDel(Aluno *lista)
{
  int matriculaAluno;
  printf("Deletando...\n");
  printf("Digite o número de matricula do aluno que deseja deletar: ");
  scanf("%d", &matriculaAluno);
  lista = retirarAluno(lista, matriculaAluno);

  return lista;
}

Disciplina *pegaDadosDi(Disciplina *lista)
{
  int idDisciplina, creditos;
  char nome[70];

  printf("Criando...\n");
  printf("Digite o nome da disciplina: ");
  scanf("%s", nome);
  printf("Digite o código da disciplina: ");
  scanf("%d", &idDisciplina);
  printf("Digite o número créditos: ");
  scanf("%d", &creditos);

  lista = insereUltimoD(lista, idDisciplina, nome, creditos);

  return lista;
}
/*Disciplina *pegaDadosDiDel(Disciplina *lista)
{
  int idDisc;
  printf("Deletando...\n");
  printf("Digite o código da disciplina: ");
  scanf("%d", &idDisc);

  lista = retirarDisciplina(lista,)
  return lista;
}*/

Turma *pegaDadosTu(Turma *lista, Disciplina *listaD)
{
  int idTurma, vagas;
  char dia[15], horario[6], sala[10], materia[70];

  printf("Criando...\n");
  printf("Digite o código da turma: ");
  scanf("%d", &idTurma);
  printf("Digite a matéria desse turma: ");
  scanf("%s", materia);
  printf("Digite o número de vagas: ");
  scanf("%d", &vagas);
  printf("Digite o dia da semana que serão as aulas ex:'segunda-feira': ");
  scanf("%s", dia);
  printf("Digite o horário de início da aula ex:'16:00': ");
  scanf("%s", horario);
  printf("Digite a sala da turma ex:'101B': ");
  scanf("%s", sala);

  lista = insereUltimoT(lista, listaD, idTurma, vagas, dia, horario, sala, materia);

  return lista;
}
/*Turma *pegaDadosTuDel(Turma *lista)
{
  NÃO IMPLEMENTEI AQUI
  return lista;
}*/

Matricula *pegaDadosMa(Matricula *lista, Aluno *listaA, Turma *listaT)
{
  char data[10];
  int matAluno, idTurma;

  printf("Criando...\n");
  printf("Digite a matrícula do aluno que deseja matricular: ");
  scanf("%d", &matAluno);
  printf("Digite o código da turma que deseja fazer a matrícula: ");
  scanf("%d", &idTurma);
  printf("Digite a data da matrícula ex: dd/mm/aaaa: ");
  scanf("%s", data);

  lista = insereUltimoM(lista, listaA, listaT, data, matAluno, idTurma);

  return lista;
}
/*Matricula *pegaDadosMaDel(Matricula *lista)
{
  NÃO IMPLEMENTEI AQUI
  return lista;
}*/

void relatorio1(Matricula *lista)
{
  int cdTurma;
  printf("Digite o código da turma: ");
  scanf("%d", &cdTurma);

  listaAlunosTurma(lista, cdTurma);
}
void relatorio3(Matricula *lista)
{
  int matAlu;

  printf("Digite o número de matrícula do aluno: ");
  scanf("%d", &matAlu);

  contDeDisciplinasAluno(lista, matAlu);
}
void menu()
{
  Aluno *listaA = NULL;
  Turma *listaT = NULL;
  Disciplina *listaD = NULL;
  Matricula *listaM = NULL;
  int escolha, idDisc, idTur, matAl;
  bool fim = false;
  //bool achei = false;
  while (fim != true)
  {
    printf("Escolha uma opção: \n");
    printf("1 - Adicionar um aluno\n");
    printf("2 - Deletar aluno conforme a matrícula\n");
    printf("3 - listar todos alunos cadastrados\n");
    printf("4 - Adicionar uma turma\n");
    printf("5 - Deletar uma turma conforme o código\n");
    printf("6 - Listar todas turmas\n");
    printf("7 - Adicionar uma disciplina\n");
    printf("8 - Deletar disciplina\n");
    printf("9 - Listar disciplinas\n");
    printf("10 - Criar matrícula\n");
    printf("11 - Deletar matrícula\n");
    printf("12 - Listar matrículas\n");
    printf("13 - R1\n");
    printf("14 - R2\n");
    printf("15 - R3\n");
    printf("16 - R4\n");
    printf("17 - R5\n");
    printf("0 - Sair\n");
    printf("Digite o número da opção para ir para a sessão desejada: ");
    scanf("%d", &escolha);
    switch (escolha)
    {
    case 0:
      liberaMa(listaM);
      liberaTu(listaT);
      liberaDi(listaD);
      liberaAl(listaA);
      fim = true;
      break;

    case 1: //add aluno
      listaA = pegaDadosAl(listaA);
      printf("\n");
      break;
    //DELETA ALUNO
    case 2: //del aluno
      //listaA = pegaDadosAlDel(listaA);
      printf("Deletando...\n");
      printf("Digite a matrícula do aluno: ");
      scanf("%d", &matAl);

      while (listaM != NULL)
      {
        if (matAl == listaM->aluno->matricula)
        {
          break;
        }
        else
        {
          listaM = listaM->proximo;
        }
      }

      listaM = retirarMatricula(listaM, listaT, matAl, listaM->turma->idTurma);
      listaA = retirarAluno(listaA, matAl);
      printf("\n");
      break;

    case 3: //list aluno
      printf("Listando...\n");
      listarAluno(listaA);
      printf("\n");
      break;

    case 4: //add turma
      listaT = pegaDadosTu(listaT, listaD);
      printf("\n");
      break;
    //DELETA TURMA
    case 5: //del turma
      printf("Deletando...\n");
      printf("Digite o código da turma: ");
      scanf("%d", &idTur);

      while (listaM != NULL)
      {
        if (idTur == listaM->turma->idTurma)
        {
          break;
        }
        else
        {
          listaM = listaM->proximo;
        }
      }

      listaM = retirarMatricula(listaM, listaT, listaM->aluno->matricula, idTur);
      listaT = retirarTurma(listaT, idTur);
      printf("\n");
      break;

    case 6: //list turma
      printf("Listando...\n");
      listarTurma(listaT);
      printf("\n");
      break;

    case 7: //add disciplina
      listaD = pegaDadosDi(listaD);
      printf("\n");
      break;
    //DELETA DISCIPLINA
    case 8: //del disciplina
      //listaD = pegaDadosDiDel(listaD);
      printf("Deletando...\n");
      printf("Digite o código da disciplina: ");
      scanf("%d", &idDisc);

      while (listaT != NULL)
      {
        if (idDisc == listaT->materia->idDisciplina)
        {
          break;
        }
        else
        {
          listaT = listaT->proximo;
        }
      }
      listaT = retirarTurma(listaT, listaT->idTurma);
      listaD = retirarDisciplina(listaD, idDisc);
      printf("\n");
      break;

    case 9: //list disciplina
      printf("Listando...\n");
      listarDisciplina(listaD);
      printf("\n");
      break;

    case 10: //add matricula
      listaM = pegaDadosMa(listaM, listaA, listaT);
      printf("\n");
      break;

    case 11: //del matricula
      listaM = retirarMatricula(listaM, listaT, 20191, 6);
      break;

    case 12: //list matricula
      printf("Listando...\n");
      listarMatricula(listaM);
      printf("\n");
      break;

    case 13: //R1
      relatorio1(listaM);
      printf("\n");
      break;

    case 14: //R2
      contDeTurmasDisciplinas(listaD);
      printf("\n");
      break;

    case 15: //R3
      relatorio3(listaM);
      printf("\n");
      break;

    case 16: //R4
      contAlunosTurma(listaT);
      printf("\n");
      break;

    case 17: //R5
      listaTurmaLot(listaT);
      printf("\n");
      break;

    default:
      printf("Opção inválida.");
      break;
    }
  }
}