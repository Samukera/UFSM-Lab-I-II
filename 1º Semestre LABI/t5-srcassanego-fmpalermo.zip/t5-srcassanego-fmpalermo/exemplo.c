// Laborat�rio I de Programa��o
//
// Programa de exemplo de uso da tela
//
// Necessita os arquivos exemplo.c (este), tela.h, tela.c e DejaVuSans.ttf
// Necessita ter instalado a biblioteca allegro5
//
// para compilar este programa, use este comando:
// gcc -Wall -o exemplo exemplo.c tela.c -lallegro_font -lallegro_color -lallegro_ttf -lallegro_primitives -lallegro
//

// Fuja das bolinhas vermelhas
// Pegue as bolinhas verdes
// Nao bata nas bordas
// Tens 30 segundos

// o tamanho da tela, em pixels
#define LARGURA_TELA 600
#define ALTURA_TELA  600

#include "tela.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>

// tipo de dados que cont�m o estado do programa.
// o programa consiste de dois circulos, um controlado pelo jogador, outro pelo jogo
// o circulo do jogo pode ser bom ou mau.
// se for mau, o jogador perde pontos quando tocar nele, se for bom, ganha pontos.
// o jogo termina por tempo.
// para cada circulo, tem valores para a posicao do centro, o raio e a velocidade
// alem disso, tem variaveis para a pontuacao e o horario de inicio do jogo.
typedef struct {
  // o circulo do jogador
  float xe, ye, re, vxe, vye;
  // o circulo do jogo
  float xi, yi, ri, vxi, vyi;
  enum { bonzinho, malvadao } tipo;
  float vmaxi; // vel maxima que um circulo pode ter
  // os pontos
  int pontos;
  // a hora de inicio
  double inicio;
} mundo_t;


// -----------------------------
// fun��es auxiliares principais

// inicializa a descri��o do nosso mundo
void inicializa_mundo(mundo_t *m);
// diz se o programa deve terminar ou n�o
bool fim_do_mundo(mundo_t *m);
// modifica o mundo de acordo com os dados de entrada
void processa_entradas(mundo_t *m);
// modifica o mundo pela passagem de tempo
void move_mundo(mundo_t *m);
// verifica os acontecimentos extraordin�rios no mundo
void verifica_mundo(mundo_t *m);
// mostra o nosso mundo para o mundo dos de fora
void desenha_mundo(mundo_t *m);

// A fun��o principal
int main(void)
{
  // inicializa a tela gr�fica
  tela_inicio(LARGURA_TELA, ALTURA_TELA, "exemplo da tela");

  // vari�vel que contem o estado do programa
  mundo_t mundo;
  inicializa_mundo(&mundo);

  // la�o principal
  while (!fim_do_mundo(&mundo)) {
    // desenha a tela de acordo com o estado atual
    desenha_mundo(&mundo);

    // altera o estado
    processa_entradas(&mundo);
    move_mundo(&mundo);
    verifica_mundo(&mundo);
  }

  sleep(2);
  // adeus, mundo cruel
  tela_fim();

  return 0;
}

// funcoes auxiliares
// calcula um numero aleat�rio entre os limites dados
float aleat(float min, float max);
// diz se um circulo ta na tela ou nao
bool ta_na_tela(float x, float y, float r);
// retorna true se dois circulos estao encostando
bool bate_bola(float x1, float y1, float r1, 
               float x2, float y2, float r2);
// inicializa a bolinha do inimigo, de forma aleat�ria
void cria_inimigo(mundo_t *m);

void inicializa_mundo(mundo_t *m)
{
  // circulo comandado externamente
  // posicao � esquerda, no centro
  m->xe = 15;
  m->ye = ALTURA_TELA/2;
  m->re = 10;
  // parado
  m->vxe = 0;
  m->vye = 0;

  // circulo que se mexe sozinho
  m->vmaxi = 3;
  cria_inimigo(m);

  m->inicio = tela_relogio();

  m->pontos = 0;
}

void desenha_mundo(mundo_t *m)
{
  // prepara a tela para ser desenhada
  tela_inicia_desenho();

  // nao � um mundo complexo, s� tem os pontos e dois c�rculos
  // desenha os pontos no meio da tela
  char s[20];
  sprintf(s, "%d", m->pontos);
  tela_texto(LARGURA_TELA/2, ALTURA_TELA/2, 26, branco, s);
  sprintf(s, "%.1f", 30 - (tela_relogio() - m->inicio));
  tela_texto(LARGURA_TELA/2, ALTURA_TELA/2+30, 18, branco, s);

  // o c�rculo do jogador
  tela_circulo(m->xe, m->ye, m->re, 2, amarelo, azul);

  // o c�rculo do jogo
  int cor;
  if (m->tipo == bonzinho) {
    cor = verde;
  } else {
    cor = vermelho;
  }
  tela_circulo(m->xi, m->yi, m->ri, 2, branco, cor);

  // fim do desenho, faz ele aparecer na tela
  tela_termina_desenho();
}

bool fim_do_mundo(mundo_t *m)
{
  // A vida � curta...
  return tela_relogio() > 30;
}

void processa_entradas(mundo_t *m)
{
  switch (tela_le_tecla()) {
    case 'w':
      m->vye--;
      break;
    case 'a':
      m->vxe--;
      break;
    case 's':
      m->vye++;
      break;
    case 'd':
      m->vxe++;
      break;
  }
}

void move_mundo(mundo_t *m)
{
  // move a bola do jogador
  m->xe += m->vxe;
  m->ye += m->vye;

  // move a bolinha do jogo
  m->xi += m->vxi;
  m->yi += m->vyi;
}

void verifica_mundo(mundo_t *m)
{
  // nao deixa jogador sair da tela (e perde pontos se bater muito forte na beirada)
  if (m->xe < 15) {
    m->xe = 15;
    if (m->vxe < -5) m->pontos -= 2;
    m->vxe = 0;
  }
  if (m->xe > LARGURA_TELA - 15) {
    m->xe = LARGURA_TELA - 15;
    if (m->vxe > 5) m->pontos -= 2;
    m->vxe = 0;
  }
  if (m->ye < 15) {
    m->ye = 15;
    if (m->vye < -5) m->pontos -= 2;
    m->vye = 0;
  }
  if (m->ye > ALTURA_TELA - 15) {
    m->ye = ALTURA_TELA - 15;
    if (m->vye > 5) m->pontos -= 2;
    m->vye = 0;
  }
  // o inimigo morre (e renasce) ao sair da tela
  if (!ta_na_tela(m->xi, m->yi, m->ri)) {
    cria_inimigo(m);
  }

  // se bolinhas encostarem, BUM
  if (bate_bola(m->xe, m->ye, m->re, m->xi, m->yi, m->ri)) {
    if (m->tipo == bonzinho) {
      m->pontos += m->ri;
    } else {
      m->pontos -= 21 - m->ri;
    }
    cria_inimigo(m);
  }
}


// implementacao das fun��es auxiliares

void cria_inimigo(mundo_t *m)
{
  // posicao aleat�ria (mas nao muito perto do jogador)
  do {
    m->xi = aleat(50, LARGURA_TELA-50);
    m->yi = aleat(50, ALTURA_TELA-50);
  } while (bate_bola(m->xe, m->ye, 50, m->xi, m->yi, 50));
  m->ri = aleat(5, 20);
  // velocidade
  m->vmaxi++; // cada vez mais r�pido!
  m->vxi = aleat(-m->vmaxi, m->vmaxi);
  m->vyi = aleat(-m->vmaxi, m->vmaxi);
  // tipo
  if (aleat(0,1) > 0.5) {
    m->tipo = bonzinho;
  } else {
    m->tipo = malvadao;
  }
}

bool ta_na_tela(float x, float y, float r)
{
  if (x-r < 0) return false;
  if (x+r > LARGURA_TELA) return false;
  if (y-r < 0) return false;
  if (y+r > ALTURA_TELA) return false;
  return true;
}

float aleat(float min, float max)
{
  float r = (float)rand()/RAND_MAX;
  return r*(max-min) + min;
}

bool bate_bola(float x1, float y1, float r1, 
               float x2, float y2, float r2)
{
  // batem se a distancia entre os centros for menor que a soma dos raios
  // (ou seus quadrados)
  return (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) < (r1+r2)*(r1+r2);
}

